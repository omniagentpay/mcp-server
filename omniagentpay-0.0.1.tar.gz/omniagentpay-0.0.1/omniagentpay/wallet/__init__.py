"""Wallet module for OmniAgentPay SDK."""

from omniagentpay.wallet.service import WalletService

__all__ = ["WalletService"]
